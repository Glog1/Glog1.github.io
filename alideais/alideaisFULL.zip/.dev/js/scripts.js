// GOOGLE MAP




var App = {

	options: {},

	init: function () {

		//Open mobile menu
		let burgerBtn = document.querySelector('.js-burger');
		let mobileMenu = document.querySelector('.js-mobile-menu');
		let mobileLogo = document.querySelector('.js-change-logo-mob .logo-d');

		burgerBtn.onclick = function () {

			if (this.classList.contains('active')) {

				mobileLogo.style.fill = '#323c5a';

			}
			else {
				mobileLogo.style.fill = '#ffffff'



			}

			mobileMenu.classList.toggle('active');
			this.classList.toggle('active');


		}

		let breadcrCaption = document.querySelector('.js-breadcrumb-caption');
		if(breadcrCaption) {
			let breadcrCaptionText = breadcrCaption.innerText;
			breadcrCaption.innerText = breadcrCaptionText.substr(0, 43) + '...';
		}


	},
	carousel: function () {

		if (document.querySelector('.js-picked-coupons-slider')) {

			let pickedCoupons = tns({
				"container": ".js-picked-coupons-slider",
				"controlsContainer": ".js-picked-coupons-slider-controls",
				"items": 1,
				"edgePadding": 50,
				"swipeAngle": false,
				"mouseDrag": true,
				"speed": 400,
				responsive: {
					768: {
						"items": 2
					}
				}
			});
		}
		if (document.querySelector('.js-picked-coupons-slider-st-2')) {

			let pickedCoupons3 = tns({
				"container": ".js-picked-coupons-slider-st-2",
				"controlsContainer": ".js-picked-coupons-slider-controls",
				"items": 1,
				"edgePadding": 50,
				"swipeAngle": false,
				"mouseDrag": true,
				"speed": 400,
				responsive: {
					768: {
						"items": 1
					}
				}
			});
		}
		if (document.querySelector('.js-picked-coupons-slider-mob')) {
			let pickedCoupons2 = tns({
				"container": ".js-picked-coupons-slider-mob",
				"controlsContainer": ".js-picked-coupons-slider-controls-mob",
				"items": 1,
				"edgePadding": 50,
				"swipeAngle": false,
				"mouseDrag": true,
				"speed": 400,
				responsive: {
					768: {
						"items": 2
					}
				}
			});
		}
		if (document.querySelector('.js-categories-slider')) {
			let CategoriesSlider2 = tns({
				"container": ".js-categories-slider",
				"controlsContainer": ".js-categories-slider-controls",
				"items": 3,
				"swipeAngle": false,
				"edgePadding": 20,
				"speed": 400,
				"mouseDrag": true,
				responsive: {
					480: {
						"items": 4,
					},
					576: {
						"items": 5,
						"edgePadding": 50,
					},
					768: {
						"items": 7,
					},
					992: {
						"items": 8,
					},
					1025: {
						"edgePadding": 0,
						"items": 5,
						"nav": false
					},
					1201: {
						"items": 6,
					},
					1367: {
						"items": 7,
					},
					1600: {
						"items": 8
					}
				}
			});
		}

		if (document.querySelector('.js-categories-slider-st-2')) {
			let CategoriesSlider2 = tns({
				"container": ".js-categories-slider-st-2",
				"controlsContainer": ".js-categories-slider-controls",
				"items": 3,
				"swipeAngle": false,
				"edgePadding": 20,
				"speed": 400,
				"mouseDrag": true,
				"nav": false,
				responsive: {
					480: {
						"items": 4,
					},
					576: {
						"items": 5,

					},
					768: {
						"items": 7,
						"edgePadding": 0,
					},
					992: {
						"items": 8,
					},
					1025: {
						"items": 5,
						"nav": true,
						"edgePadding": 80,

					},
					1201: {
						"items": 6,
					},
					1367: {
						"items": 7,
					},
					1600: {
						"items": 8
					}
				}
			});
		}

		if (document.querySelector('.js-recommend-product')) {
			let recommendSlider= tns({
				"container": ".js-recommend-product",
				"controlsContainer": ".js-recommend-slider-controls",
				"items": 1,
				"edgePadding": 15,
				"swipeAngle": false,
				"mouseDrag": true,
				"speed": 400,
				"nav": false,

				responsive: {
					// 576: {
					// 	"items": 2,
					// },
					768: {
						"items": 2,
						"edgePadding": 0,
					},
					1367: {
						"items": 3
					}
				}

			});
		}

		if (document.querySelector('.js-watched-product')) {
			let watcheddSlider= tns({
				"container": ".js-watched-product",
				"controlsContainer": ".js-watched-slider-controls",
				"items": 1,
				"edgePadding": 15,
				"swipeAngle": false,
				"mouseDrag": true,
				"speed": 400,
				"nav": false,

				responsive: {
					// 576: {
					// 	"items": 2,
					// },
					768: {
						"items": 2,
						"edgePadding": 0,
					},
					1367: {
						"items": 3
					}
				}

			});
		}
	}
};

(function() {

	App.init(),
	App.carousel()

})();

